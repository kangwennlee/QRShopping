﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode.Codec.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace VirtualWall2018
{
    public partial class InsertProduct : System.Web.UI.Page
    {
        DBVirtualDataContext db = new DBVirtualDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            String json = "";
            String pid = "";
            if (Request.QueryString["action"] == "insert")
            {
                if (Request.QueryString["pid"] != null && Request.QueryString["pid"] != null && Request.QueryString["pid"] != null)
                {
                    pid = Request.QueryString["pid"].ToString();
                    String pname = Request.QueryString["pname"].ToString();
                    String pprice = Request.QueryString["pprice"].ToString();

                    if (pid != null && pname != null && pprice != null)
                    {
                        Product p = new Product()
                        {
                            ProdId = pid.ToUpper(),
                            ProdName = pname,
                            ProdPrice = pprice
                        };

                        db.Products.InsertOnSubmit(p);
                        db.SubmitChanges();

                        QRCodeEncoder encoder = new QRCodeEncoder();
                        for (int j = 1; j < 10; j++)
                        {
                            Bitmap img = encoder.Encode(pid.ToUpper());
                            var img_name = "/QR_Images/" + pid.ToUpper() + ".jpg";
                            img.Save(HttpContext.Current.Server.MapPath(img_name));
                        }

                        json = "{ \"Result\":\"Insert Success.\" }";
                    }
                    else
                    {
                        json = "{ \"Result\":\"Insert Failed.\" }";
                    }
                }
                
            }
            else if (Request.QueryString["action"] == "update")
            {
                if (Request.QueryString["pid"] != null)
                {
                    pid = Request.QueryString["pid"].ToString();

                    if (db.Products.Any(x => x.ProdId == pid.ToUpper()))
                    {
                        Product p = db.Products.FirstOrDefault(x => x.ProdId == pid.ToUpper());
                        if (Request.QueryString["pname"] != null) p.ProdName = Request.QueryString["pname"].ToString();
                        if (Request.QueryString["pprice"] != null) p.ProdPrice = Request.QueryString["pprice"].ToString();
                        db.SubmitChanges();

                        json = "{ \"Result\":\"Update Success.\" }";
                    }
                    else
                    {
                        json = "{ \"Result\":\"No such Id.\" }";
                    }
                }
            }
            else if (Request.QueryString["action"] == "delete")
            {
                if (Request.QueryString["pid"] != null)
                {
                    pid = Request.QueryString["pid"].ToString();
                    if (db.Products.Any(x => x.ProdId == pid.ToUpper()))
                    {   
                        Product p = db.Products.FirstOrDefault(x => x.ProdId == pid.ToUpper());
                        db.Products.DeleteOnSubmit(p);
                        db.SubmitChanges();

                        json = "{ \"Result\":\"Delete Success.\" }";
                    }
                    else
                    {
                        json = "{ \"Result\":\"No such Id.\" }";
                    }
                   
                }
            }
            else
            {
                json = "{ \"Result\":\"Failed\" }";
            }
            

            Response.Clear();
            Response.ContentType = "application/json; charset=utf-8";
            Response.Write(json);
            Response.End();

        }
    }
}